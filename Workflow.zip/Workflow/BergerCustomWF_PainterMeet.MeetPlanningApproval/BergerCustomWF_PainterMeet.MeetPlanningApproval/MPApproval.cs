﻿
namespace BergerWorkflowUtilities.PainterMeet.MeetPlanningApproval
{
    using System;
    using System.IO;
    using System.Net;
    using System.Configuration;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Runtime.Serialization;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Win32;
    using System.Activities;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;
    using Microsoft.Xrm.Sdk.Workflow.Activities;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// Custom work flow activity class to set meet planning approver.
    /// </summary>
    public class MPApproval : CodeActivity
    {       
        public System.Configuration.Configuration config;
        public static PragmasysLogger oPragmasysLogger;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;
            string DepotUserRoleName = string.Empty;
            string RSMUserRoleName = string.Empty;
            string HoUserRoleName = string.Empty;

            try
            {
                /// <summary>eset
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                #region To Read Config File
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();


                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        //string _PragmasysLoggerPath = config.AppSettings.Settings["PragmasysLoggerpath"].Value.ToString();
                        string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oPragmasysLogger = new PragmasysLogger(_organizationName, _loggerPath);
                        DepotUserRoleName = config.AppSettings.Settings["depotuserrole"].Value.ToString();
                        RSMUserRoleName = config.AppSettings.Settings["rsmuserrole"].Value.ToString();
                        HoUserRoleName = config.AppSettings.Settings["houserrole"].Value.ToString();
                    }
                }
                #endregion

                Entity MeetId = new Entity();
                Entity MeetRecord = new Entity();
                EntityReference RetUser = new EntityReference();

                MeetId = RetriveMeetPlanning(entityId, service, oPragmasysLogger);

                if (!String.IsNullOrEmpty(MeetId.LogicalName))
                {
                    MeetRecord = RetriveMeetRecord(((EntityReference)MeetId.Attributes["ber_meet"]).Id, service, oPragmasysLogger);
                    if (MeetId.Contains("statuscode"))
                    {
                        #region If User is Depot User
                        if (((GetUserRole(iworkflowcontext.UserId, service, DepotUserRoleName, oPragmasysLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oPragmasysLogger)) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oPragmasysLogger)) && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                        {
                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {
                                if (MeetRecord.Contains("ber_rsmapproval") && MeetId.Contains("statuscode") && MeetRecord.Attributes["ber_rsmapproval"].ToString() == "True")
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                    {
                                        if (MeetId.Contains("ber_depot"))
                                        {
                                            EntityReference Depot = ((EntityReference)MeetId.Attributes["ber_depot"]);

                                            EntityReference Region = RetriveRegionfromDepot(Depot.Id, service, oPragmasysLogger);

                                            if (!String.IsNullOrEmpty(Region.LogicalName))
                                            {
                                                EntityReference RSMUser = RetriveRSMfromRegion(Region.Id, service, oPragmasysLogger);
                                                if (!String.IsNullOrEmpty(RSMUser.LogicalName))
                                                {
                                                    RetUser = SharingRecord(entityName, entityId, RSMUser, service, oPragmasysLogger);
                                                    ChangeStatus(entityId, 0, 278290000, service, oPragmasysLogger);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (MeetRecord.Contains("ber_hoapproval") && MeetId.Contains("statuscode") && MeetRecord.Attributes["ber_hoapproval"].ToString() == "True")
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                    {
                                        if (MeetRecord.Contains("ber_hoapproverid"))
                                        {
                                            EntityReference HOUser = ((EntityReference)MeetRecord.Attributes["ber_hoapproverid"]);

                                            if (!String.IsNullOrEmpty(HOUser.LogicalName))
                                            {
                                                RetUser = SharingRecord(entityName, entityId, HOUser, service, oPragmasysLogger);
                                                ChangeStatus(entityId, 0, 278290001, service, oPragmasysLogger);
                                            }
                                        }
                                    }
                                }
                                else if (MeetId.Contains("statuscode"))
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oPragmasysLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oPragmasysLogger);
                                    }
                                }
                            }                            
                        }
                        #endregion

                        #region If User is RSM User
                        if (((GetUserRole(iworkflowcontext.UserId, service, RSMUserRoleName, oPragmasysLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oPragmasysLogger))
                            || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oPragmasysLogger))
                            && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                        {                  
                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {                         
                                if (MeetRecord.Contains("ber_hoapproval") && MeetId.Contains("statuscode"))
                                {
                                    if (MeetRecord.Attributes["ber_hoapproval"].ToString() == "True" && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        if (MeetRecord.Contains("ber_hoapproverid"))
                                        {
                                            EntityReference HOUser = ((EntityReference)MeetRecord.Attributes["ber_hoapproverid"]);

                                            if (!String.IsNullOrEmpty(HOUser.LogicalName))
                                            {
                                                RetUser = SharingRecord(entityName, entityId, HOUser, service, oPragmasysLogger);
                                                ChangeStatus(entityId, 0, 278290001, service, oPragmasysLogger);
                                            }
                                        }
                                    }
                                    else if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oPragmasysLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oPragmasysLogger);

                                    }
                                }
                                else if (MeetId.Contains("statuscode"))
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oPragmasysLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oPragmasysLogger);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region if User is HO Approver
                        if (((GetUserRole(iworkflowcontext.UserId, service, HoUserRoleName, oPragmasysLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oPragmasysLogger)) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oPragmasysLogger)) && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290001")
                        {
                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {
                                if (MeetId.Contains("statuscode"))
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290001")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oPragmasysLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oPragmasysLogger);
                                    }
                                }
                            }
                        }
                        #endregion

                        if (!String.IsNullOrEmpty(RetUser.LogicalName) && RetUser.LogicalName != "Error")
                        {                          
                            //Set Approver User on meet planning.
                            Entity updateMeetPlanning = new Entity();
                            updateMeetPlanning.LogicalName = entityName;
                            updateMeetPlanning.Id = entityId;
                            updateMeetPlanning["ber_currentapproverid"] = new EntityReference(RetUser.LogicalName, RetUser.Id);
                            service.Update(updateMeetPlanning);
                        }
                        else
                        {
                            oPragmasysLogger.Log("MeetPlanningApproval", "Execute", "The user is not authorised to execute the workflow.", "Calling User Id: " + iworkflowcontext.UserId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oPragmasysLogger.Log("MeetPlanningApproval", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetUserRole(Guid UserId, IOrganizationService service, string RoleName, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                QueryExpression RetriveUserRoles = new QueryExpression();
                RetriveUserRoles.EntityName = "systemuserroles";

                ConditionExpression UserRetrivalCondition = new ConditionExpression();
                UserRetrivalCondition.AttributeName = "systemuserid";
                UserRetrivalCondition.Operator = ConditionOperator.Equal;
                UserRetrivalCondition.Values.Add(UserId);

                FilterExpression UserRetrivalFilter = new FilterExpression();
                UserRetrivalFilter.FilterOperator = LogicalOperator.And;
                UserRetrivalFilter.AddCondition(UserRetrivalCondition);

                LinkEntity RolelinkEntity = new LinkEntity();
                RolelinkEntity.JoinOperator = JoinOperator.Inner;
                RolelinkEntity.LinkFromEntityName = "systemuserroles";
                RolelinkEntity.LinkFromAttributeName = "roleid";
                RolelinkEntity.LinkToEntityName = "role";
                RolelinkEntity.LinkToAttributeName = "roleid";
                RolelinkEntity.Columns.AddColumn("name");

                RetriveUserRoles.Criteria = UserRetrivalFilter;
                RetriveUserRoles.LinkEntities.Add(RolelinkEntity);

                EntityCollection RolesCollection = service.RetrieveMultiple(RetriveUserRoles);

                foreach (Entity role in RolesCollection.Entities)
                {
                    if (role.Contains("role1.name"))
                    {
                        if (((AliasedValue)role["role1.name"]).Value.ToString() == RoleName)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "GetUserRole", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected Entity RetriveMeetRecord(Guid MeetId, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet MeetColumns = new ColumnSet();
                MeetColumns.AddColumn("ber_rsmapproval");
                MeetColumns.AddColumn("ber_hoapproval");
                MeetColumns.AddColumn("ber_hoapproverid");

                Entity MeetRecord = service.Retrieve("ber_meet", MeetId, MeetColumns);

                return MeetRecord;
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "RetriveMeetRecord", ex.Message, ex.StackTrace.ToString());
                return new Entity();
            }

        }

        protected Entity RetriveMeetPlanning(Guid MeetPlanningId, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet PainterMeetColumns = new ColumnSet();
                PainterMeetColumns.AddColumn("ber_meet");
                PainterMeetColumns.AddColumn("ber_depot");
                PainterMeetColumns.AddColumn("statuscode");

                Entity MeetPlanningRecord = service.Retrieve("ber_paintermeet", MeetPlanningId, PainterMeetColumns);

                if (MeetPlanningRecord.Contains("ber_meet"))
                {
                    return MeetPlanningRecord;
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "RetriveMeetPlanning", ex.Message, ex.StackTrace.ToString());
            }
            return new Entity();
        }

        protected EntityReference SharingRecord(string entityName, Guid entityId, EntityReference AssigneeUser, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                GrantAccessRequest ShareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ShareAccess | AccessRights.AppendToAccess | AccessRights.ReadAccess | AccessRights.AppendAccess | AccessRights.WriteAccess,
                        Principal = AssigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };

                service.Execute(ShareRequest);

                return AssigneeUser;
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "SharingRecord", ex.Message, ex.StackTrace.ToString());
                EntityReference User = new EntityReference();
                User.LogicalName = "Error";
                return User;
                //throw Ex;
            }
            //return new EntityReference();
        }

        protected EntityReference RetriveRSMfromRegion(Guid RegionId, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet RegionColumns = new ColumnSet();
                RegionColumns.AddColumn("ber_rsm");

                Entity Region = service.Retrieve("ber_region", RegionId, RegionColumns);

                if (Region.Contains("ber_rsm"))
                {
                    return ((EntityReference)Region.Attributes["ber_rsm"]);
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "RetriveRSMfromRegion", ex.Message, ex.StackTrace.ToString());
            }
            return new EntityReference();
        }

        protected EntityReference RetriveRegionfromDepot(Guid DepotId, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet DepotColumns = new ColumnSet();
                DepotColumns.AddColumn("ber_region");
                Entity DepotRecord = service.Retrieve("ber_depot", DepotId, DepotColumns);

                if (DepotRecord.Contains("ber_region"))
                {
                    return ((EntityReference)DepotRecord.Attributes["ber_region"]);
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "RetriveRegionfromDepot", ex.Message, ex.StackTrace.ToString());
            }
            return new EntityReference();
        }

        protected void ChangeStatus(Guid MeetPlanningid, int state, int status, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                // Create the Request Object
                SetStateRequest stateRequest = new SetStateRequest();

                // Set the Request Object's Properties
                stateRequest.State = new OptionSetValue(state);
                stateRequest.Status = new OptionSetValue(status);

                EntityReference MeetPlanning = new EntityReference("ber_paintermeet", MeetPlanningid);

                stateRequest.EntityMoniker = MeetPlanning;
                // Execute the Request
                SetStateResponse stateSet = (SetStateResponse)service.Execute(stateRequest);
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "ChangeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetApproverofRecord(string entityname, Guid RecordId, Guid UserGuid, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet OwnerColumn = new ColumnSet();
                OwnerColumn.AddColumn("ber_currentapproverid");

                Entity MeetPlanningRecord = service.Retrieve(entityname, RecordId, OwnerColumn);

                if (MeetPlanningRecord.Contains("ber_currentapproverid"))
                {
                    EntityReference User = (EntityReference)MeetPlanningRecord.Attributes["ber_currentapproverid"];

                    if (User.Id == UserGuid)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "GetApproverofRecord", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected EntityReference SetCreatedbyASApprover(string logicalname, Guid recordid, IOrganizationService service, PragmasysLogger oPragmasysLogger)
        {
            try
            {
                ColumnSet CreatedByColumns = new ColumnSet();
                CreatedByColumns.AddColumn("createdby");

                Entity MPRecord = service.Retrieve(logicalname, recordid, CreatedByColumns);

                if (MPRecord.Contains("createdby"))
                {
                    EntityReference CreatedByUser = (EntityReference)MPRecord.Attributes["createdby"];

                    return CreatedByUser;
                }
            }
            catch (Exception ex)
            {
                oPragmasysLogger.Log("MeetPlanningApproval", "SetCreatedbyASApprover", ex.Message, ex.StackTrace.ToString());
                EntityReference User = new EntityReference();
                User.LogicalName = "Error";
                return User;
                //throw ex;
            }
            return new EntityReference();
        }
    }
}
