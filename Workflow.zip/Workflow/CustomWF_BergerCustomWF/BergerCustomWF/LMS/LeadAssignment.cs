﻿//===========================================================================================================
//  This Custom workflow activity is used for assigning LEAD to the specific user based on Lead Type.
//
//  In Lead Management on Creation of lead the lead gets assigned to the user present on Depot.
//  If the Lead Type is Home Decor then the Lead gets assigned to Home Decor user present on the Depot.
//  OR 
//  IF the Lead Type is BDM then the Lead gets assigned to BDM user present on Depot.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.LMS
{
    public class LeadAssignment : CodeActivity
    {
        public System.Configuration.Configuration config;
        [Input("Recipient")]
        [ReferenceTarget("ber_city")]
        public InArgument<EntityReference> RecipientProperty { get; set; }

        [Output("AssignedUser")]
        [ReferenceTarget("systemuser")]
        public OutArgument<EntityReference> AssignedUser { get; set; }

        public static Logger oLogger;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            //Use Logger to Log Error Entry in ErrorLog Table.
            //pass Log File path Where want to put Logfile
            //Logger oLogger = new Logger(_organizationName, Loggerpath);

            //Obtain the value of Input Parameter.
            EntityReference City = executionContext.GetValue(this.RecipientProperty);

            try
            {
                ColumnSet LeadTypeColumns = new ColumnSet();
                LeadTypeColumns.AddColumn("ber_leadtype");

                Entity LeadType = service.Retrieve(entityName, entityId, LeadTypeColumns);
                EntityReference RetAssignedUser = new EntityReference();
                if (LeadType.Contains("ber_leadtype"))
                {
                    string LeadTypeValue = ((OptionSetValue)LeadType.Attributes["ber_leadtype"]).Value.ToString();
                    Entity CityRecord = new Entity();
                    EntityReference DepotUser = new EntityReference();
                    EntityReference Depot = new EntityReference();

                    if (LeadTypeValue == "278290000")
                    {
                        #region BDM Lead
                        CityRecord = RetriveCityDepot(service, City, LeadTypeValue, oLogger);
                        //If City has BDM Depot
                        if (CityRecord.Contains("ber_bdmdepotid"))
                        {
                            Depot = ((EntityReference)CityRecord.Attributes["ber_bdmdepotid"]);
                            DepotUser = RetriveDepotUser(service, Depot, "ber_bdmid", oLogger);

                            if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                            {
                                RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                            }
                            else
                            {
                                //If BDM Depot Doesnot have User
                                CityRecord = RetriveCityDepot(service, City, "defaultdepot", oLogger);
                                if (CityRecord.Contains("ber_defaultdepotid"))
                                {
                                    DepotUser = RetriveDepotUser(service, Depot, "ber_bdmid", oLogger);

                                    if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                                    {
                                        RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                                    }
                                }
                            }
                        }
                        //If City Doesnot have BDM Depot then Default Depot is considered
                        else if (CityRecord.Contains("ber_defaultdepotid"))
                        {
                            Depot = ((EntityReference)CityRecord.Attributes["ber_defaultdepotid"]);
                            DepotUser = RetriveDepotUser(service, Depot, "ber_bdmid", oLogger);

                            if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                            {
                                RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                            }
                        }
                        #endregion
                    }
                    else if (LeadTypeValue == "278290001")
                    {
                        #region HomeDecor Lead
                        CityRecord = RetriveCityDepot(service, City, LeadTypeValue, oLogger);
                        //If Home Decor Depot is present on city
                        if (CityRecord.Contains("ber_homedecordepotid"))
                        {
                            Depot = ((EntityReference)CityRecord.Attributes["ber_homedecordepotid"]);
                            DepotUser = RetriveDepotUser(service, Depot, "ber_homedecoruserid", oLogger);

                            if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                            {
                                RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                            }
                            else
                            {
                                //If User is not present on home decor depot
                                CityRecord = RetriveCityDepot(service, City, "defaultdepot", oLogger);
                                if (CityRecord.Contains("ber_defaultdepotid"))
                                {
                                    Depot = ((EntityReference)CityRecord.Attributes["ber_defaultdepotid"]);
                                    DepotUser = RetriveDepotUser(service, Depot, "ber_homedecoruserid", oLogger);

                                    if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                                    {
                                        RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                                    }
                                }
                            }
                        }
                        // If Home Decor Depot is not Present on city then Default Depot would be considered
                        else if (CityRecord.Contains("ber_defaultdepotid"))
                        {
                            Depot = ((EntityReference)CityRecord.Attributes["ber_defaultdepotid"]);
                            DepotUser = RetriveDepotUser(service, Depot, "ber_homedecoruserid", oLogger);

                            if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                            {
                                RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        #region If Lead is not BDM or HD
                        CityRecord = RetriveCityDepot(service, City, "defaultdepot", oLogger);
                        //If Lead Is not of BDM Or HD then default depot would be considred for assignment
                        if (CityRecord.Contains("ber_defaultdepotid"))
                        {
                            Depot = ((EntityReference)CityRecord.Attributes["ber_defaultdepotid"]);
                            DepotUser = RetriveDepotUser(service, Depot, "ber_depotuser", oLogger);

                            if (!String.IsNullOrEmpty(DepotUser.LogicalName))
                            {
                                RetAssignedUser = AssignLead(service, DepotUser, entityName, entityId, oLogger);
                            }
                        }
                        #endregion
                    }
                }
                if (!String.IsNullOrEmpty(RetAssignedUser.LogicalName) && RetAssignedUser.LogicalName != "Error")
                {
                    //Set Ouput Parameter where User is assigned
                    AssignedUser.Set(executionContext, new EntityReference(RetAssignedUser.LogicalName, RetAssignedUser.Id));
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("HDLeadAssignment", "Execute", ex.Message, ex.StackTrace);
            }
        }

        /// <summary>
        /// Assigns Lead To User
        /// </summary>
        /// <param name="service">IOrganizationService object</param>
        /// <param name="DUser">Assignee User</param>
        /// <param name="LeadName">Lead Entity Logical Name</param>
        /// <param name="LeadId">Lead Record Id</param>
        /// <param name="oLogger">Logger Object</param>
        /// <returns></returns>
        protected EntityReference AssignLead(IOrganizationService service, EntityReference DUser, string LeadName, Guid LeadId, Logger oLogger)
        {
            EntityReference AssignedUser = new EntityReference();
            try
            {
                AssignRequest assign = new AssignRequest
                {
                    Assignee = new EntityReference(DUser.LogicalName, DUser.Id),
                    Target = new EntityReference(LeadName, LeadId)
                };

                service.Execute(assign);

                AssignedUser.Id = DUser.Id;
                AssignedUser.LogicalName = DUser.LogicalName;
                AssignedUser.Name = DUser.Name;

                return AssignedUser;
            }
            catch (Exception ex)
            {
                AssignedUser.LogicalName = "Error";
                oLogger.Log("HDLeadAssignment", "AssignLead", ex.Message, ex.StackTrace);
                return AssignedUser;
            }
        }

        /// <summary>
        /// retrives Depot from City
        /// </summary>
        /// <param name="service">IOrganizationService object</param>
        /// <param name="City">Record of City Entity</param>
        /// <param name="LeadType">Value of Lead Type</param>
        /// <param name="oLogger">Logger Object</param>
        /// <returns></returns>
        protected Entity RetriveCityDepot(IOrganizationService service, EntityReference City, string LeadType, Logger oLogger)
        {
            try
            {
                ColumnSet CityColumns = new ColumnSet();
                if (LeadType == "278290000")
                {
                    CityColumns.AddColumn("ber_bdmdepotid");
                }
                else if (LeadType == "278290001")
                {
                    CityColumns.AddColumn("ber_homedecordepotid");
                }
                CityColumns.AddColumn("ber_defaultdepotid");


                Entity CityRecord = service.Retrieve(City.LogicalName, City.Id, CityColumns);
                return CityRecord;
            }
            catch (Exception ex)
            {
                oLogger.Log("LeadAssignment", "RetriveCityDepot", ex.Message, ex.StackTrace);
                return new Entity();
            }
        }

        /// <summary>
        /// Retrives desired Depot User from Depot
        /// </summary>
        /// <param name="service">IOrganizationService object</param>
        /// <param name="Depot">Depot Record</param>
        /// <param name="depotfieldname">Name of User Lookup Name</param>
        /// <param name="oLogger">Logger Class Object</param>
        /// <returns></returns>
        protected EntityReference RetriveDepotUser(IOrganizationService service, EntityReference Depot, string depotfieldname, Logger oLogger)
        {
            try
            {
                ColumnSet DepotColumns = new ColumnSet();
                DepotColumns.AddColumn(depotfieldname);

                Entity DepotRecord = service.Retrieve(Depot.LogicalName, Depot.Id, DepotColumns);

                if (DepotRecord.Contains(depotfieldname))
                {
                    EntityReference User = (EntityReference)DepotRecord.Attributes[depotfieldname];
                    return User;
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("LeadAssignment", "RetriveDepotUser", ex.Message, ex.StackTrace);
            }
            return new EntityReference();
        }
    }
}
