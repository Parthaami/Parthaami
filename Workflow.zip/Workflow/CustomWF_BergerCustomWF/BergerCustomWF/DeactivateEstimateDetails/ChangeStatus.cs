﻿// =====================================================================
//  This Customer Workflow Activity is used to Deactivate Home Decor Estimates.
//  In HD if customer approves any one estimate from few estimates generated for a specific Lead 
//  then on customer acceptance other estimates of that lead gets inactive using this workflow.
//
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using System.Data.SqlClient;
using System.Data;


namespace BergerWorkflowUtilities.DeactivateEstimateDetails
{
    public class ChangeStatus : CodeActivity
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;
        public static string SQLConnStr = string.Empty;
     

        protected override void Execute(CodeActivityContext executionContext)
        {
            try
            {
                //Create the tracing service
                ITracingService tracingService = executionContext.GetExtension<ITracingService>();

                //Create the context
                IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

                //Get the GUID and Name of entity.
                Guid entityId = iworkflowcontext.PrimaryEntityId;
                string entityName = iworkflowcontext.PrimaryEntityName;
                string _organizationName = iworkflowcontext.OrganizationName;

                #region To Read Config File
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);
                        SQLConnStr = config.ConnectionStrings.ConnectionStrings["Bergersqldbconnection"].ConnectionString.ToString();
                    }
                }
                #endregion

                string getLeadQry = "select ber_LeadId from ber_estimatedetails (nolock) " +
                                    "where ber_estimatedetailsId='"+ entityId.ToString() +"'";

                DataTable dtLead = getDataFromSql(getLeadQry, SQLConnStr);

                if (dtLead.Rows.Count > 0 && dtLead.Rows[0][0] != DBNull.Value)
                {
                    string EstimateDetailsQry = "select ber_estimatedetailsId from ber_estimatedetails as t1 (nolock) " +
                                                "inner join Lead as t2 (nolock) on t1.ber_LeadId = t2.LeadId " +
                                                "where t1.ber_LeadId='" + Convert.ToString(dtLead.Rows[0][0]) + "' " +
                                                "and t1.statecode='0'";

                    DataTable dtEstimateDtl = getDataFromSql(EstimateDetailsQry, SQLConnStr);

                    if (dtEstimateDtl.Rows.Count > 0 && dtEstimateDtl.Rows[0][0] != DBNull.Value)
                    {
                        for (int i = 0; i < dtEstimateDtl.Rows.Count; i++)
                        {
                            if (entityId != new Guid(dtEstimateDtl.Rows[i][0].ToString()))
                            {
                                SetStateRequest request = new SetStateRequest();
                                request.EntityMoniker = new EntityReference(entityName, new Guid(dtEstimateDtl.Rows[i][0].ToString()));
                                request.State = new OptionSetValue(1);
                                request.Status = new OptionSetValue(2);
                                SetStateResponse oresponse = (SetStateResponse)service.Execute(request);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("DeactivateEstimateDetails", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        #region Function to get Data from SQL
        public static DataTable getDataFromSql(string Query, string _dbConnectionString)
        {
            DataTable DT = new DataTable();
            SqlConnection connection = new SqlConnection(_dbConnectionString);
            connection.Open();
            SqlCommand command = new SqlCommand(Query, connection);

            SqlDataReader reader = null;
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 120;
                reader = command.ExecuteReader();
                DT.Load(reader);
            }
            catch (Exception ex)
            {
                oLogger.Log("DeactivateEstimateDetails", "getDataFromSql: " + Query, ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                connection.Close();
                reader.Dispose();
                command.Dispose();
                connection.Dispose();
                Query = string.Empty;
            }
            return DT;
        }
        #endregion
    }
}
