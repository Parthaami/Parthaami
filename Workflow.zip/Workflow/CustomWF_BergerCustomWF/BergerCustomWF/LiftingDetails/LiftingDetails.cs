﻿//===========================================================================================================
//  This Custom workflow activity is used to assign lifting details registered by painter/DG/Dealer to that depot BDM user.
//  In Painter Meet Module when any lifting details gets registered in CRM that record gets assigned to BDM user of the
//  specified depot.(BDM User is present on Depot only)
//
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.LiftingDetails
{
    public class LiftingDetails : CodeActivity
    {
        public System.Configuration.Configuration config;
        [Input("Dealer")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> RecipientProperty { get; set; }

        [Output("AssignedUser")]
        [ReferenceTarget("systemuser")]
        public OutArgument<EntityReference> AssignedUser { get; set; }

        public static Logger oLogger;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>

            
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            //Use Logger to Log Error Entry in ErrorLog Table.
            //pass Log File path Where want to put Logfile
            //Logger oLogger = new Logger(_organizationName, Loggerpath);

            //Obtain the value of Input Parameter.
            EntityReference DealerRef = executionContext.GetValue(this.RecipientProperty);

            try
            {
                EntityReference BDMUser = RetriveBDMUserformDepot(DealerRef, service);

                if (!String.IsNullOrEmpty(BDMUser.LogicalName) && BDMUser.LogicalName != "Error")
                {
                    //Set Ouput Parameter where User is assigned
                    AssignedUser.Set(executionContext, new EntityReference(BDMUser.LogicalName, BDMUser.Id));
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("LiftingDetails", "Execute", ex.Message, ex.StackTrace);
            }
        }

        protected EntityReference RetriveBDMUserformDepot(EntityReference Dealer,IOrganizationService service)
        {
            try
            {
                ColumnSet DealerColumns = new ColumnSet();
                DealerColumns.AddColumn("ber_depotid");

                Entity DealerRecord = service.Retrieve(Dealer.LogicalName, Dealer.Id, DealerColumns);

                if (DealerRecord.Contains("ber_depotid"))
                {
                    EntityReference DepotRef = (EntityReference)DealerRecord.Attributes["ber_depotid"];

                    ColumnSet DepotColumns = new ColumnSet();
                    DepotColumns.AddColumn("ber_bdmid");

                    Entity DepotRecord = service.Retrieve(DepotRef.LogicalName, DepotRef.Id, DepotColumns);

                    if (DepotRecord.Contains("ber_bdmid"))
                    {
                        return (EntityReference)DepotRecord.Attributes["ber_bdmid"];
                    }
                }

                return new EntityReference();
            }
            catch (Exception ex)
            {
                oLogger.Log("LiftingDetails", "RetriveBDMUserformDepot", ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
