// =====================================================================
//  This Customer Workflow Activity is Generic activity used to share a target Record with specified user.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using BergerWorkflowUtilities;

namespace BergerWorkflowUtilities.ShareStep.Share
{
    public class Share : CodeActivity
    {
        protected override void Execute(CodeActivityContext executionContext)
        {
            try
            {
                //Create the context and tracing service
                IExecutionContext context = executionContext.GetExtension<IExecutionContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                ITracingService tracer = executionContext.GetExtension<ITracingService>();

                EntityReference callingUser = new EntityReference("systemuser", context.UserId);

                EntityReference user = User.Get(executionContext);
                EntityReference team = Team.Get(executionContext);
                if (user == null && team == null)
                {
                    Helpers.Throw("Must specify either user or team to share the record with");
                }

                if (PrimaryEntity.Get(executionContext))
                {
                    tracer.Trace("Sharing process primary entity");
                    ShareWithUserTeam(new EntityReference(context.PrimaryEntityName, context.PrimaryEntityId), executionContext, user, team, callingUser, service);
                }
                else
                {
                    string relatedAttribute = RelatedAttributeName.Get(executionContext);
                    if (string.IsNullOrEmpty(relatedAttribute))
                    {
                        Helpers.Throw("If sharing related entity, related attribute name must be specified in the process share step configuration");
                    }

                    // Retrieve primary entity with the required attribute
                    tracer.Trace("Retrieving process primary entity");
                    Entity primaryEntity = service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, new ColumnSet(relatedAttribute));

                    if (primaryEntity.Contains(relatedAttribute))
                    {
                        EntityReference reference = primaryEntity[relatedAttribute] as EntityReference;
                        if (reference == null)
                        {
                            Helpers.Throw(string.Format("The attribute {0} on entity {1} is expected to be of EntityReference type",
                                relatedAttribute, context.PrimaryEntityName));
                        }

                        tracer.Trace("Sharing entity related to primary entity by attribute " + relatedAttribute);
                        ShareWithUserTeam(reference, executionContext, user, team, callingUser, service);
                    }
                }

            }
            catch (Exception ex)
            {
               Helpers.Throw(String.Format("An error occurred in the {0} plug-in.",
                       this.GetType().ToString()),
                     ex);
            }

            return;
        }

        private AccessRights ComputeAccessRights(CodeActivityContext executionContext, EntityReference target, EntityReference callingUser, IOrganizationService service)
        {
            // Retrieve the privileges that the current user has on the record
            RetrievePrincipalAccessRequest retrieveAccessRightsReq = new RetrievePrincipalAccessRequest()
            {
                Target = target,
                Principal = callingUser,
            };
            RetrievePrincipalAccessResponse retrieveAccessRightsResp = (RetrievePrincipalAccessResponse)service.Execute(retrieveAccessRightsReq);

            AccessRights accessRights = AccessRights.None;
            
            if (ShareAppend.Get(executionContext))
            {
                accessRights |= AccessRights.AppendAccess;
            }
            if (ShareAppendTo.Get(executionContext))
            {
                accessRights |= AccessRights.AppendToAccess;
            }
            if (ShareAssign.Get(executionContext))
            {
                accessRights |= AccessRights.AssignAccess;
            }
            if (ShareDelete.Get(executionContext))
            {
                accessRights |= AccessRights.DeleteAccess;
            }
            if (ShareRead.Get(executionContext))
            {
                accessRights |= AccessRights.ReadAccess;
            }
            if (ShareShare.Get(executionContext))
            {
                accessRights |= AccessRights.ShareAccess;
            }
            if (ShareWrite.Get(executionContext))
            {
                accessRights |= AccessRights.WriteAccess;
            }
            
            return accessRights;
        }

        private void ShareWithUserTeam(EntityReference target, CodeActivityContext executionContext, EntityReference user, EntityReference team, EntityReference callingUser, IOrganizationService service)
        {
            AccessRights accessRights = ComputeAccessRights(executionContext, target, callingUser, service);
            if (user != null)
            {
                ShareRecord(target, user, accessRights, service);
            }
            if (team != null)
            {
                ShareRecord(target, team, accessRights, service);
            }
        }

        private void ShareRecord(EntityReference target, EntityReference principal, AccessRights rights, IOrganizationService service)
        {
            GrantAccessRequest grantRequest = new GrantAccessRequest()
            {
                Target = target,
                PrincipalAccess = new PrincipalAccess()
                {
                    Principal = principal,
                    AccessMask = rights
                }
            };
            service.Execute(grantRequest);
        }

        #region Input Parameters

        [RequiredArgument]
        [Input("Share primary entity (True) or related entity (False)")]
        public InArgument<bool> PrimaryEntity { get; set; }

        [Input("If sharing related entity, specify attribute name to get the related entity")]
        public InArgument<string> RelatedAttributeName { get; set; }

        [Input("User to share the record with")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }

        [Input("Team to share the record with")]
        [ReferenceTarget("team")]
        public InArgument<EntityReference> Team { get; set; }

        /// <summary>
        /// Share Read privilege.
        /// </summary>
        [Input("Read Permission")]
        [Default("True")]
        public InArgument<bool> ShareRead { get; set; }

        /// <summary>
        /// Share Write privilege.
        /// </summary>
        [Input("Write Permission")]
        [Default("False")]
        public InArgument<bool> ShareWrite { get; set; }

        /// <summary>
        /// Share Delete privilege.
        /// </summary>
        [Input("Delete Permission")]
        [Default("False")]
        public InArgument<bool> ShareDelete { get; set; }

        /// <summary>
        /// Share Append privilege.
        /// </summary>
        [Input("Append Permission")]
        [Default("False")]
        public InArgument<bool> ShareAppend { get; set; }

        /// <summary>
        /// Share AppendTo privilege.
        /// </summary>
        [Input("Append To Permission")]
        [Default("False")]
        public InArgument<bool> ShareAppendTo { get; set; }

        /// <summary>
        /// Share Assign privilege.
        /// </summary>
        [Input("Assign Permission")]
        [Default("False")]
        public InArgument<bool> ShareAssign { get; set; }

        /// <summary>
        /// Share Share privilege.
        /// </summary>
        [Input("Share Permission")]
        [Default("False")]
        public InArgument<bool> ShareShare { get; set; }

        #endregion

        #region Output Parameters
        #endregion
    }
}
