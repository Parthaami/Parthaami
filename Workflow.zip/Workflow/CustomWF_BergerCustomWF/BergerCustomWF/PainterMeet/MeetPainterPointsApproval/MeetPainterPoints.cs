﻿// =====================================================================
//  This Custom Workflow activity is used to change the status of Meet Painter Records.
//  After Calculating the Meet Painter Earned points using windows service,this workflow gets called
//  it changes the meet painter record status accordingly.
// 
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.PainterMeet.MeetPainterPointsApproval
{
    public class MeetPainterPoints : CodeActivity
    {
        public System.Configuration.Configuration config;
        [Input("OptionSetValue input")]
        [AttributeTarget("ber_paintermeetcontact", "statuscode")]
        [RequiredArgument]
        public InArgument<OptionSetValue> OptionSetValueProperty { get; set; }


        [Input("EntityReference input")]
        [ReferenceTarget("ber_meet")]
        [RequiredArgument]
        public InArgument<EntityReference> MeetEntityReference { get; set; }

        public static Logger oLogger;
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            //Obtain the value of Input Parameter.            
            OptionSetValue StatusReason = executionContext.GetValue(this.OptionSetValueProperty);
            EntityReference MeetRef = executionContext.GetValue(this.MeetEntityReference);

            try
            {  //  Get configration data             
                //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                fileMap.ExeConfigFilename = configpath;
                this.config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

                if (StatusReason.Value == 278290003 && (CheckOwner(iworkflowcontext.UserId, entityName, entityId, service, oLogger) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger)))
                {
                    ChangeStatus(entityName, entityId, 278290000, 0, service, oLogger);
                }
                else if (StatusReason.Value == 278290000 && (CheckHoApprover(MeetRef, iworkflowcontext.UserId, service, oLogger) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger)))
                {
                    ChangeStatus(entityName, entityId, 278290001, 0, service, oLogger);
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("ApproveMeetPainterPoints", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool CheckHoApprover(EntityReference Meet,Guid UserId,IOrganizationService service,Logger oLogger)
        {
            try
            {
                ColumnSet MeetColumns = new ColumnSet();
                MeetColumns.AddColumn("ber_hoapproverid");

                Entity MeetRecord = service.Retrieve(Meet.LogicalName, Meet.Id, MeetColumns);

                if (MeetRecord.Contains("ber_hoapproverid"))
                {
                    EntityReference HOApprover = (EntityReference)MeetRecord.Attributes["ber_hoapproverid"];

                    if (HOApprover.Id == UserId)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("ApproveMeetPainterPoints", "CheckHoApprover", ex.Message, ex.StackTrace.ToString());
                return false;                
            }
        }

        protected void ChangeStatus(string EntityName, Guid EntityId, int statusreason, int statecode, IOrganizationService service, Logger oLogger)
        {
            try
            {
                SetStateRequest SetStatus = new SetStateRequest();

                SetStatus.EntityMoniker = new EntityReference(EntityName, EntityId);

                SetStatus.Status = new OptionSetValue(Convert.ToInt32(statusreason));
                SetStatus.State = new OptionSetValue(Convert.ToInt32(statecode));

                SetStateResponse stateSet = (SetStateResponse)service.Execute(SetStatus);
            }
            catch (Exception ex)
            {
                oLogger.Log("ApproveMeetPainterPoints", "ChangeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetUserRole(Guid UserId, IOrganizationService service, string RoleName, Logger oLogger)
        {
            try
            {
                QueryExpression RetriveUserRoles = new QueryExpression();
                RetriveUserRoles.EntityName = "systemuserroles";

                ConditionExpression UserRetrivalCondition = new ConditionExpression();
                UserRetrivalCondition.AttributeName = "systemuserid";
                UserRetrivalCondition.Operator = ConditionOperator.Equal;
                UserRetrivalCondition.Values.Add(UserId);

                FilterExpression UserRetrivalFilter = new FilterExpression();
                UserRetrivalFilter.FilterOperator = LogicalOperator.And;
                UserRetrivalFilter.AddCondition(UserRetrivalCondition);

                LinkEntity RolelinkEntity = new LinkEntity();
                RolelinkEntity.JoinOperator = JoinOperator.Inner;
                RolelinkEntity.LinkFromEntityName = "systemuserroles";
                RolelinkEntity.LinkFromAttributeName = "roleid";
                RolelinkEntity.LinkToEntityName = "role";
                RolelinkEntity.LinkToAttributeName = "roleid";
                RolelinkEntity.Columns.AddColumn("name");

                RetriveUserRoles.Criteria = UserRetrivalFilter;
                RetriveUserRoles.LinkEntities.Add(RolelinkEntity);

                EntityCollection RolesCollection = service.RetrieveMultiple(RetriveUserRoles);

                foreach (Entity role in RolesCollection.Entities)
                {
                    if (role.Contains("role1.name"))
                    {
                        if (((AliasedValue)role["role1.name"]).Value.ToString() == RoleName)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("ApproveMeetPainterPoints", "GetUserRole", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected bool CheckOwner(Guid UserId, string EntityName, Guid EntityId, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet MeetPainterColumns = new ColumnSet();
                MeetPainterColumns.AddColumn("ownerid");

                Entity MeetPainterRecord = service.Retrieve(EntityName, EntityId, MeetPainterColumns);

                if (MeetPainterRecord.Contains("ownerid"))
                {
                    EntityReference Owner = (EntityReference)MeetPainterRecord.Attributes["ownerid"];

                    if (Owner.Id == UserId)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return true;
                }
                
            }
            catch (Exception ex)
            {
                oLogger.Log("ApproveMeetPainterPoints", "CheckOwner", ex.Message, ex.StackTrace.ToString());
                return false;                
            }
        }        
    }
}
