﻿// =====================================================================
//  This Custom Workflow activity is used to Launch the Meet Plaining which is approved by HO user.
//  Depot user will run the workflow LAUNCH MEET ondemand to launch the meet plaining.On Execution 
//  of this workflow the Meet Plaining status gets changed from APPROVE to Launched.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.PainterMeet.MeetPlanningLaunch
{
    public class LaunchMeet : CodeActivity
    {
        public System.Configuration.Configuration config;
        public static Logger oLogger;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            //Use Logger to Log Error Entry in ErrorLog Table.
            //pass Log File path Where want to put Logfile
            try
            {  //  Get configration data             
                //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                fileMap.ExeConfigFilename = configpath;
                this.config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

                if (GetOwnerofRecord(entityName, entityId, iworkflowcontext.UserId, service, oLogger) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger))
                {
                    ColumnSet MeetPlanningColumnset = new ColumnSet();
                    MeetPlanningColumnset.AddColumn("statuscode");

                    Entity MeetPlanningRecord = service.Retrieve(entityName, entityId, MeetPlanningColumnset);

                    if (MeetPlanningRecord.Contains("statuscode"))
                    {
                        if (((OptionSetValue)MeetPlanningRecord.Attributes["statuscode"]).Value.ToString() == "278290002")
                        {
                            ChangeStatus(entityId, 0, 278290004, service, oLogger);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("MeetPlanningLaunch", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetUserRole(Guid UserId, IOrganizationService service, string RoleName, Logger oLogger)
        {
            try
            {
                QueryExpression RetriveUserRoles = new QueryExpression();
                RetriveUserRoles.EntityName = "systemuserroles";

                ConditionExpression UserRetrivalCondition = new ConditionExpression();
                UserRetrivalCondition.AttributeName = "systemuserid";
                UserRetrivalCondition.Operator = ConditionOperator.Equal;
                UserRetrivalCondition.Values.Add(UserId);

                FilterExpression UserRetrivalFilter = new FilterExpression();
                UserRetrivalFilter.FilterOperator = LogicalOperator.And;
                UserRetrivalFilter.AddCondition(UserRetrivalCondition);

                LinkEntity RolelinkEntity = new LinkEntity();
                RolelinkEntity.JoinOperator = JoinOperator.Inner;
                RolelinkEntity.LinkFromEntityName = "systemuserroles";
                RolelinkEntity.LinkFromAttributeName = "roleid";
                RolelinkEntity.LinkToEntityName = "role";
                RolelinkEntity.LinkToAttributeName = "roleid";
                RolelinkEntity.Columns.AddColumn("name");

                RetriveUserRoles.Criteria = UserRetrivalFilter;
                RetriveUserRoles.LinkEntities.Add(RolelinkEntity);

                EntityCollection RolesCollection = service.RetrieveMultiple(RetriveUserRoles);

                foreach (Entity role in RolesCollection.Entities)
                {
                    if (role.Contains("role1.name"))
                    {
                        if (((AliasedValue)role["role1.name"]).Value.ToString() == RoleName)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningLaunch", "GetUserRole", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected void ChangeStatus(Guid MeetPlanningid, int state, int status, IOrganizationService service, Logger oLogger)
        {
            try
            {
                // Create the Request Object
                SetStateRequest stateRequest = new SetStateRequest();

                // Set the Request Object's Properties
                stateRequest.State = new OptionSetValue(state);
                stateRequest.Status = new OptionSetValue(status);

                EntityReference MeetPlanning = new EntityReference("ber_paintermeet", MeetPlanningid);

                stateRequest.EntityMoniker = MeetPlanning;
                // Execute the Request
                SetStateResponse stateSet = (SetStateResponse)service.Execute(stateRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningLaunch", "ChangeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetOwnerofRecord(string entityname, Guid RecordId, Guid UserGuid, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet OwnerColumn = new ColumnSet();
                OwnerColumn.AddColumn("ownerid");

                Entity MeetPlanningRecord = service.Retrieve(entityname, RecordId, OwnerColumn);

                if (MeetPlanningRecord.Contains("ownerid"))
                {
                    EntityReference User = (EntityReference)MeetPlanningRecord.Attributes["ownerid"];

                    if (User.Id == UserGuid)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningLaunch", "GetOwnerofRecord", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }
    }
}
