﻿// =====================================================================
//  This Custom Workflow Activity is used to approve Meet Plaining.
//  It is used in Ondemand workflow,which is triggered by HO user when any Meet Plaining
//  record comes to HO user for approval from depot.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.PainterMeet.MeetPlanningApproval
{
    public class MPApproval : CodeActivity
    {
        public System.Configuration.Configuration config;

        [Output("ApproverUser")]
        [ReferenceTarget("systemuser")]
        public OutArgument<EntityReference> ApproverUser { get; set; }

        public static Logger oLogger;
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            try
            {  //  Get configration data             
                //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                fileMap.ExeConfigFilename = configpath;
                this.config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                Entity MeetId = new Entity();
                Entity MeetRecord = new Entity();

                EntityReference RetUser = new EntityReference();

                string DepotUserRoleName = config.AppSettings.Settings["depotuserrole"].Value.ToString();
                string RSMUserRoleName = config.AppSettings.Settings["rsmuserrole"].Value.ToString();
                string HoUserRoleName = config.AppSettings.Settings["houserrole"].Value.ToString();

                MeetId = RetriveMeetPlanning(entityId, service, oLogger);

                if (!String.IsNullOrEmpty(MeetId.LogicalName))
                {
                    MeetRecord = RetriveMeetRecord(((EntityReference)MeetId.Attributes["ber_meet"]).Id, service, oLogger);
                    if (MeetId.Contains("statuscode"))
                    {
                        #region If User is Depot User
                        if (((GetUserRole(iworkflowcontext.UserId, service, DepotUserRoleName, oLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oLogger)) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger)) && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                        {
                            //MeetId = RetriveMeetPlanning(entityId, service);

                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {
                                //MeetRecord = RetriveMeetRecord(((EntityReference)MeetId.Attributes["ber_meet"]).Id, service);
                                if (MeetRecord.Contains("ber_rsmapproval") && MeetId.Contains("statuscode") && MeetRecord.Attributes["ber_rsmapproval"].ToString() == "True")
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1" )
                                    {
                                        if (MeetId.Contains("ber_depot"))
                                        {
                                            EntityReference Depot = ((EntityReference)MeetId.Attributes["ber_depot"]);

                                            EntityReference Region = RetriveRegionfromDepot(Depot.Id, service, oLogger);

                                            if (!String.IsNullOrEmpty(Region.LogicalName))
                                            {
                                                EntityReference RSMUser = RetriveRSMfromRegion(Region.Id, service, oLogger);
                                                if (!String.IsNullOrEmpty(RSMUser.LogicalName))
                                                {
                                                    RetUser = SharingRecord(entityName, entityId, RSMUser, service, oLogger);
                                                    ChangeStatus(entityId, 0, 278290000, service, oLogger);
                                                }
                                            }
                                        }
                                    }
                                }
                                    else if (MeetRecord.Contains("ber_hoapproval") && MeetId.Contains("statuscode") && MeetRecord.Attributes["ber_hoapproval"].ToString() == "True")
                                    {
                                        if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                        {
                                            if (MeetRecord.Contains("ber_hoapproverid"))
                                            {
                                                EntityReference HOUser = ((EntityReference)MeetRecord.Attributes["ber_hoapproverid"]);

                                                if (!String.IsNullOrEmpty(HOUser.LogicalName))
                                                {
                                                    RetUser = SharingRecord(entityName, entityId, HOUser, service, oLogger);
                                                    ChangeStatus(entityId, 0, 278290001, service, oLogger);
                                                }
                                            }
                                        }
                                    }
                                    else if (MeetId.Contains("statuscode"))
                                    {
                                        if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                        {
                                            ChangeStatus(entityId, 0, 278290002, service, oLogger);
                                            RetUser = SetCreatedbyASApprover(entityName, entityId, service, oLogger);
                                        }
                                    }
                                }
                                //else if (MeetRecord.Contains("ber_hoapproval") && MeetId.Contains("statuscode"))
                                //{
                                //    if (MeetRecord.Attributes["ber_hoapproval"].ToString() == "True" && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "1")
                                //    {
                                //        if (MeetRecord.Contains("ber_hoapproverid"))
                                //        {
                                //            EntityReference HOUser = ((EntityReference)MeetRecord.Attributes["ber_hoapproverid"]);

                                //            if (!String.IsNullOrEmpty(HOUser.LogicalName))
                                //            {
                                //                ChangeStatus(entityId, 0, 278290002, service, oLogger);
                                //                RetUser = SetCreatedbyASApprover(entityName, entityId, service, oLogger);
                                //            }
                                //        }
                                //    }
                                //}
                            }
                        //}
                        #endregion

                        #region If User is RSM User
                        if (((GetUserRole(iworkflowcontext.UserId, service, RSMUserRoleName, oLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oLogger))
                            || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger)) 
                            && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                        {
                            //MeetId = RetriveMeetPlanning(entityId, service);

                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {
                                //MeetRecord = RetriveMeetRecord(((EntityReference)MeetId.Attributes["ber_meet"]).Id, service);

                                if (MeetRecord.Contains("ber_hoapproval") && MeetId.Contains("statuscode"))
                                {
                                    if (MeetRecord.Attributes["ber_hoapproval"].ToString() == "True" && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        if (MeetRecord.Contains("ber_hoapproverid"))
                                        {
                                            EntityReference HOUser = ((EntityReference)MeetRecord.Attributes["ber_hoapproverid"]);

                                            if (!String.IsNullOrEmpty(HOUser.LogicalName))
                                            {
                                                RetUser = SharingRecord(entityName, entityId, HOUser, service, oLogger);
                                                ChangeStatus(entityId, 0, 278290001, service, oLogger);
                                            }
                                        }
                                    }
                                    else if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oLogger);

                                    }
                                }
                                else if (MeetId.Contains("statuscode"))
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290000")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oLogger);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region if User is HO Approver
                        if (((GetUserRole(iworkflowcontext.UserId, service, HoUserRoleName, oLogger) && GetApproverofRecord(entityName, entityId, iworkflowcontext.UserId, service, oLogger)) || GetUserRole(iworkflowcontext.UserId, service, "System Administrator", oLogger)) && ((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290001")
                        {
                            //MeetId = RetriveMeetPlanning(entityId, service);
                            if (!String.IsNullOrEmpty(MeetId.LogicalName))
                            {
                                //MeetRecord = RetriveMeetRecord(((EntityReference)MeetId.Attributes["ber_meet"]).Id, service);
                                if (MeetId.Contains("statuscode"))
                                {
                                    if (((OptionSetValue)MeetId.Attributes["statuscode"]).Value.ToString() == "278290001")
                                    {
                                        ChangeStatus(entityId, 0, 278290002, service, oLogger);
                                        RetUser = SetCreatedbyASApprover(entityName, entityId, service, oLogger);
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }

                if (!String.IsNullOrEmpty(RetUser.LogicalName) && RetUser.LogicalName != "Error")
                {
                    //Set Ouput Parameter where User is assigned
                    ApproverUser.Set(executionContext, new EntityReference(RetUser.LogicalName, RetUser.Id));
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("MeetPlanningApproval", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool GetUserRole(Guid UserId, IOrganizationService service, string RoleName, Logger oLogger)
        {
            try
            {
                QueryExpression RetriveUserRoles = new QueryExpression();
                RetriveUserRoles.EntityName = "systemuserroles";                

                ConditionExpression UserRetrivalCondition = new ConditionExpression();
                UserRetrivalCondition.AttributeName = "systemuserid";
                UserRetrivalCondition.Operator = ConditionOperator.Equal;
                UserRetrivalCondition.Values.Add(UserId);

                FilterExpression UserRetrivalFilter = new FilterExpression();
                UserRetrivalFilter.FilterOperator = LogicalOperator.And;
                UserRetrivalFilter.AddCondition(UserRetrivalCondition);

                LinkEntity RolelinkEntity = new LinkEntity();
                RolelinkEntity.JoinOperator = JoinOperator.Inner;
                RolelinkEntity.LinkFromEntityName = "systemuserroles";
                RolelinkEntity.LinkFromAttributeName = "roleid";
                RolelinkEntity.LinkToEntityName = "role";
                RolelinkEntity.LinkToAttributeName = "roleid";
                RolelinkEntity.Columns.AddColumn("name");

                RetriveUserRoles.Criteria = UserRetrivalFilter;
                RetriveUserRoles.LinkEntities.Add(RolelinkEntity);

                EntityCollection RolesCollection = service.RetrieveMultiple(RetriveUserRoles);

                foreach (Entity role in RolesCollection.Entities)
                {
                    if (role.Contains("role1.name"))
                    {
                        if (((AliasedValue)role["role1.name"]).Value.ToString() == RoleName)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "GetUserRole", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected Entity RetriveMeetRecord(Guid MeetId, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet MeetColumns = new ColumnSet();
                MeetColumns.AddColumn("ber_rsmapproval");
                MeetColumns.AddColumn("ber_hoapproval");
                MeetColumns.AddColumn("ber_hoapproverid");

                Entity MeetRecord = service.Retrieve("ber_meet", MeetId, MeetColumns);

                return MeetRecord;
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "RetriveMeetRecord", ex.Message, ex.StackTrace.ToString());
                return new Entity();                
            }
            
        }

        protected Entity RetriveMeetPlanning(Guid MeetPlanningId, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet PainterMeetColumns = new ColumnSet();
                PainterMeetColumns.AddColumn("ber_meet");
                PainterMeetColumns.AddColumn("ber_depot");
                PainterMeetColumns.AddColumn("statuscode");

                Entity MeetPlanningRecord = service.Retrieve("ber_paintermeet", MeetPlanningId, PainterMeetColumns);

                if (MeetPlanningRecord.Contains("ber_meet"))
                {
                    return MeetPlanningRecord;
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "RetriveMeetPlanning", ex.Message, ex.StackTrace.ToString());
            }
            return new Entity();
        }

        protected EntityReference SharingRecord(string entityName, Guid entityId, EntityReference AssigneeUser, IOrganizationService service, Logger oLogger)
        {
            try
            {
                GrantAccessRequest ShareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ShareAccess | AccessRights.AppendToAccess | AccessRights.ReadAccess | AccessRights.AppendAccess | AccessRights.WriteAccess,
                        Principal = AssigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };

                service.Execute(ShareRequest);

                return AssigneeUser;
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "SharingRecord", ex.Message, ex.StackTrace.ToString());
                EntityReference User = new EntityReference();
                User.LogicalName = "Error";
                return User;
                //throw Ex;
            }
            //return new EntityReference();
        }

        protected EntityReference RetriveRSMfromRegion(Guid RegionId, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet RegionColumns = new ColumnSet();
                RegionColumns.AddColumn("ber_rsm");

                Entity Region = service.Retrieve("ber_region", RegionId, RegionColumns);

                if (Region.Contains("ber_rsm"))
                {
                    return ((EntityReference)Region.Attributes["ber_rsm"]);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "RetriveRSMfromRegion", ex.Message, ex.StackTrace.ToString());
            }
            return new EntityReference();
        }

        protected EntityReference RetriveRegionfromDepot(Guid DepotId, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet DepotColumns = new ColumnSet();
                DepotColumns.AddColumn("ber_region");
                Entity DepotRecord = service.Retrieve("ber_depot", DepotId, DepotColumns);

                if (DepotRecord.Contains("ber_region"))
                {
                    return ((EntityReference)DepotRecord.Attributes["ber_region"]);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "RetriveRegionfromDepot", ex.Message, ex.StackTrace.ToString());
            }
            return new EntityReference();
        }

        protected void ChangeStatus(Guid MeetPlanningid, int state, int status, IOrganizationService service, Logger oLogger)
        {
            try
            {
                // Create the Request Object
                SetStateRequest stateRequest = new SetStateRequest();

                // Set the Request Object's Properties
                stateRequest.State = new OptionSetValue(state);
                stateRequest.Status = new OptionSetValue(status);

                EntityReference MeetPlanning = new EntityReference("ber_paintermeet", MeetPlanningid);

                stateRequest.EntityMoniker = MeetPlanning;
                // Execute the Request
                SetStateResponse stateSet = (SetStateResponse)service.Execute(stateRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "ChangeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }

        /*protected void AssignRecord(string logicalname,Guid recordid,EntityReference SystemUser,IOrganizationService service)
        {
            try
            {
                AssignRequest assign = new AssignRequest
                {
                    Assignee = new EntityReference(SystemUser.LogicalName,SystemUser.Id),
                    Target = new EntityReference(logicalname,recordid)
                };
                // Execute the Request
                service.Execute(assign);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/

        protected bool GetApproverofRecord(string entityname, Guid RecordId, Guid UserGuid, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet OwnerColumn = new ColumnSet();
                OwnerColumn.AddColumn("ber_currentapproverid");

                Entity MeetPlanningRecord = service.Retrieve(entityname, RecordId, OwnerColumn);

                if (MeetPlanningRecord.Contains("ber_currentapproverid"))
                {
                    EntityReference User = (EntityReference)MeetPlanningRecord.Attributes["ber_currentapproverid"];

                    if (User.Id == UserGuid)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "GetApproverofRecord", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        /*protected void AssignRecordToCreatedBy(string logicalname, Guid recordid,IOrganizationService service)
        {
            try
            {
                ColumnSet CreatedByColumns = new ColumnSet();
                CreatedByColumns.AddColumn("createdby");

                Entity MPRecord = service.Retrieve(logicalname, recordid, CreatedByColumns);

                if (MPRecord.Contains("createdby"))
                {
                    EntityReference CreatedByUser = (EntityReference)MPRecord.Attributes["createdby"];

                    AssignRecord(logicalname, recordid, CreatedByUser, service);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/

        protected EntityReference SetCreatedbyASApprover(string logicalname, Guid recordid, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet CreatedByColumns = new ColumnSet();
                CreatedByColumns.AddColumn("createdby");

                Entity MPRecord = service.Retrieve(logicalname, recordid, CreatedByColumns);

                if (MPRecord.Contains("createdby"))
                {
                    EntityReference CreatedByUser = (EntityReference)MPRecord.Attributes["createdby"];

                    return CreatedByUser;
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MeetPlanningApproval", "SetCreatedbyASApprover", ex.Message, ex.StackTrace.ToString());
                EntityReference User = new EntityReference();
                User.LogicalName = "Error";
                return User;
                //throw ex;
            }
            return new EntityReference();
        }
    }
}
