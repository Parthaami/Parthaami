﻿// =====================================================================
//  This Workflow activity is used to increase BD Budget of perticular depot.
//  On Sanction Request Record to increase depot BD Budget, add depot and on execution
//  Ondemand workflow this custom activity gets triggered and adds the specified amount into Depot 
//  BD Budget accordingly.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;


namespace BergerWorkflowUtilities.PainterMeet.SanctionRequest
{
    public class SanctionRequest : CodeActivity
    {
        public System.Configuration.Configuration config;

        public static Logger oLogger;
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     

                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            //Obtain the value of Input Parameter.            

            try
            {  //  Get configration data             
                //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                fileMap.ExeConfigFilename = configpath;
                this.config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

                if (CheckStatus(entityName, entityId, 0, service, oLogger))
                {
                    decimal SanctionAmount = 0;
                    EntityCollection SRFDetails = GetSRFDetails(entityId, entityName, service, oLogger);

                    foreach (Entity SRFDetail in SRFDetails.Entities)
                    {
                        if (SRFDetail.Contains("ber_depotid") && SRFDetail.Contains("ber_amount"))
                        {
                            decimal allocatedbudget = RetriveDepot((EntityReference)SRFDetail.Attributes["ber_depotid"], service, oLogger);

                            decimal amount = ((Money)SRFDetail.Attributes["ber_amount"]).Value;

                            UpdateDepot((EntityReference)SRFDetail.Attributes["ber_depotid"], allocatedbudget + amount, service, oLogger);

                            ChangeStatus(SRFDetail.LogicalName, SRFDetail.Id, 2, 1, service, oLogger);

                            SanctionAmount += amount;
                        }
                    }

                    UpdateSanctionRequestAmount(entityName, entityId, SanctionAmount, service, oLogger);
                    ChangeStatus(entityName, entityId, 2, 1, service, oLogger);
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("SanctionrequestWF", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected bool CheckStatus(string entityname, Guid entityid, int status, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet SanctionRequestColumns = new ColumnSet();
                SanctionRequestColumns.AddColumn("statecode");

                Entity SanctionRequestRecord = service.Retrieve(entityname, entityid, SanctionRequestColumns);

                if(SanctionRequestRecord.Contains("statecode"))
                {
                    OptionSetValue StatusOptionset = (OptionSetValue)SanctionRequestRecord.Attributes["statecode"];

                    if (StatusOptionset.Value == status)
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "CheckStatus", ex.Message, ex.StackTrace.ToString());
            }
            return false;
        }

        protected EntityCollection GetSRFDetails(Guid SanctionRequestId, string SanctionRequestName, IOrganizationService service, Logger oLogger)
        {
            try
            {
                QueryExpression SRFDetailRetriveQuery = new QueryExpression();
                SRFDetailRetriveQuery.EntityName = "ber_srfdetail";
                SRFDetailRetriveQuery.ColumnSet.AddColumn("ber_depotid");
                SRFDetailRetriveQuery.ColumnSet.AddColumn("ber_amount");

                ConditionExpression SRFDetailCondition = new ConditionExpression();
                SRFDetailCondition.AttributeName = "ber_srf";
                SRFDetailCondition.Operator = ConditionOperator.Equal;
                SRFDetailCondition.Values.Add(SanctionRequestId);

                FilterExpression SRFDetailFilter = new FilterExpression();
                SRFDetailFilter.AddCondition(SRFDetailCondition);
                SRFDetailFilter.FilterOperator = LogicalOperator.And;

                SRFDetailRetriveQuery.Criteria = SRFDetailFilter;

                EntityCollection SRFDetailsCollection = service.RetrieveMultiple(SRFDetailRetriveQuery);

                return SRFDetailsCollection;
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "GetSRFDetails", ex.Message, ex.StackTrace.ToString());
                return new EntityCollection();                
            }            
        }

        protected decimal RetriveDepot(EntityReference Depot, IOrganizationService service, Logger oLogger)
        {
            try
            {
                ColumnSet DepotColumns = new ColumnSet();
                DepotColumns.AddColumn("ber_bdbudget");

                Entity Depotrecord = service.Retrieve(Depot.LogicalName, Depot.Id, DepotColumns);

                if (Depotrecord.Contains("ber_bdbudget"))
                {
                    Money allocatedbudget = (Money)Depotrecord.Attributes["ber_bdbudget"];

                    return allocatedbudget.Value;
                }
                return 0;
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "RetriveDepot", ex.Message, ex.StackTrace.ToString());
                return 0;                
            }            
        }

        protected void UpdateDepot(EntityReference Depot, decimal budget, IOrganizationService service, Logger oLogger)
        {
            try
            {
                Entity newDepot = new Entity(Depot.LogicalName);
                newDepot.Id = Depot.Id;
                newDepot["ber_bdbudget"] = new Money(budget);

                service.Update(newDepot);
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "UpdateDepot", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected void ChangeStatus(string EntityName, Guid EntityId, int statusreason, int statecode, IOrganizationService service, Logger oLogger)
        {
            try
            {
                SetStateRequest SetStatus = new SetStateRequest();

                SetStatus.EntityMoniker = new EntityReference(EntityName, EntityId);

                SetStatus.Status = new OptionSetValue(Convert.ToInt32(statusreason));
                SetStatus.State = new OptionSetValue(Convert.ToInt32(statecode));
                
                SetStateResponse stateSet = (SetStateResponse)service.Execute(SetStatus);
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "ChangeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }

        protected void UpdateSanctionRequestAmount(string EntityName, Guid EntityId, decimal Amount, IOrganizationService service, Logger oLogger)
        {
            try
            {
                Entity newSanctionRequest = new Entity();
                newSanctionRequest.Id = EntityId;
                newSanctionRequest.LogicalName = EntityName;
                newSanctionRequest["ber_amount"] = new Money(Amount);

                service.Update(newSanctionRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("SanctionrequestWF", "UpdateSanctionRequestAmount", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
