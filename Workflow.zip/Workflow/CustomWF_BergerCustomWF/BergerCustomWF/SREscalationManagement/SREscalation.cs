﻿// =====================================================================
//  This Customer Workflow Activity is used in Service Request Management.
//  On Creation SR record this WF activity gets triggered and few values on SR like
//  Escalation 1,2,3 dates ,SR Due date & Escaltion 1,2,3 email id's.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Text;
using System.IO;
using System.Net;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Workflow.Activities;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;


namespace BergerWorkflowUtilities.SREscalationManagement
{
    public class SREscalation : CodeActivity
    {
        #region Input Attributes
        [Input("SR Type")]
        [ReferenceTarget("pcl_srtype")]
        [RequiredArgument]
        public InArgument<EntityReference> SRTypeProperty { get; set; }

        [Input("SUB SR Type")]
        [ReferenceTarget("pcl_subsrtype")]
        [RequiredArgument]
        public InArgument<EntityReference> SUBSRTypeProperty { get; set; }

        [Input("Depot")]
        [ReferenceTarget("ber_depot")]
        [RequiredArgument]
        public InArgument<EntityReference> DepotProperty { get; set; }

        [Input("Customer Category")]
        [AttributeTarget("account", "accountcategorycode")]
        [RequiredArgument]
        public InArgument<OptionSetValue> CustomerTypeProperty { get; set; }

        [Input("Location")]
        [AttributeTarget("account", "accountratingcode")]
        [RequiredArgument]
        public InArgument<OptionSetValue> LocationProperty { get; set; }

        [Input("Color Bank Service Request")]
        [AttributeTarget("pcl_srtype","ber_colorbanksrtype")]
        [Default("false")]
        public InArgument<bool> IsColorBankSRTypeProperty { get; set; }

        [Input("Saturday Weekend")]
        public InArgument<bool> IsSaturdayWeekend { get; set; }

        [Input("Sunday Weekend")]
        public InArgument<bool> IsSundayWeekend { get; set; }
        #endregion

        #region Class Level Variables
        public static string _loggerPath = string.Empty;
        public System.Configuration.Configuration config;
        public static Logger oLogger;
        public static Guid CaseId = Guid.Empty;

        public static int DepoManager = 1;
        public static int DepoUser = 2;
        public static int RSM = 3;
        public static int others = 4;
        public static int NA = 4;

        public static double EscTAT1 = 0;
        public static double EscTAT2 = 0;
        public static double EscTAT3 = 0;

        public static int EscTo1 = 0;
        public static int EscTo2 = 0;
        public static int EscTo3 = 0;

        public static DateTime EscDate1;
        public static DateTime EscDate2;
        public static DateTime EscDate3;

        public static string EscEmail1 = string.Empty;
        public static string EscEmail2 = string.Empty;
        public static string EscEmail3 = string.Empty;

        public static List<string> WeekEndDays;
        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            CaseId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;

            try
            {
                /// <summary>eset
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                #region To Read Config File
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();


                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);
                    }
                }
                #endregion


                //Obtain the value of Input Parameter.
                EntityReference SRType = executionContext.GetValue(this.SRTypeProperty);
                EntityReference SubSRType = executionContext.GetValue(this.SUBSRTypeProperty);
                EntityReference Depot = executionContext.GetValue(this.DepotProperty);                
                OptionSetValue CustomerCategory = executionContext.GetValue(this.CustomerTypeProperty);
                OptionSetValue Location = executionContext.GetValue(this.LocationProperty);
                bool ColorBankServieRequest = executionContext.GetValue(this.IsColorBankSRTypeProperty);

                WeekEndDays = new List<string>();

                if (executionContext.GetValue(this.IsSaturdayWeekend))
                {
                    WeekEndDays.Add("Saturday");
                }

                if (executionContext.GetValue(this.IsSundayWeekend))
                {
                    WeekEndDays.Add("Sunday");
                }

                EntityCollection oCaseConfiguration;

                //Color Bank Service Request
                if (ColorBankServieRequest)
                {
                    oCaseConfiguration = RetriveCaseConfig(_service, SRType.Id, SubSRType.Id, CustomerCategory.Value, Location.Value);
                }
                else
                {
                    oCaseConfiguration = RetriveCaseConfig(_service, SRType.Id, SubSRType.Id);
                }                               

                foreach (Entity CaseConfigEntity in oCaseConfiguration.Entities)
                {
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationtat1"))
                    {
                        EscTAT1 = Convert.ToDouble(CaseConfigEntity.Attributes["ber_escalationtat1"].ToString());
                    }
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationtat2"))
                    {
                        EscTAT2 = Convert.ToDouble(CaseConfigEntity.Attributes["ber_escalationtat2"].ToString());
                    }
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationtat3"))
                    {
                        EscTAT3 = Convert.ToDouble(CaseConfigEntity.Attributes["ber_escalationtat3"].ToString());
                    }
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationto1"))
                    {
                        EscTo1 = ((OptionSetValue)CaseConfigEntity.Attributes["ber_escalationto1"]).Value;
                    }
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationto2"))
                    {
                        EscTo2 = ((OptionSetValue)CaseConfigEntity.Attributes["ber_escalationto2"]).Value;
                    }
                    if (CaseConfigEntity.Attributes.Contains("ber_escalationto3"))
                    {
                        EscTo3 = ((OptionSetValue)CaseConfigEntity.Attributes["ber_escalationto3"]).Value;
                    }


                    #region If Escalation TAT 1 > 0
                    if (EscTAT1 > 0)
                    {
                        DateTime TempEscDate = DateTime.Now;

                        if (CaseConfigEntity.Attributes.Contains("ber_servicecategory"))
                        {
                            //when service type is complaint and calls reported after 4.00pm on any working day shall be considered as calls of 9:30am of the next working day
                            if (((OptionSetValue)CaseConfigEntity.Attributes["ber_servicecategory"]).Value == 278290000)
                            {
                                if (TempEscDate.Hour > 15)
                                {
                                    TempEscDate = TempEscDate.AddDays(1);
                                    TempEscDate = ChangeTime(TempEscDate, 9, 35, 0, 0);
                                }
                            }
                        }
                        EscDate1 = getEscalationDate(_service, TempEscDate, EscTAT1);
                        if (EscTo1 == DepoUser)//DepoUser
                        {
                            EscEmail1 = getDepoUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo1 == DepoManager)//DepoManager
                        {
                            //Entity oDepot = _service.Retrieve("ber_depot", Depot.Id, new ColumnSet(new string[] {"emailaddress"}));
                            Entity oDepot = _service.Retrieve("ber_depot", Depot.Id, new ColumnSet(new string[] { "ber_escalationemail" }));
                            if (oDepot.Attributes.Contains("ber_escalationemail"))
                                EscEmail1 = oDepot.Attributes["ber_escalationemail"].ToString();
                        }
                        else if (EscTo1 == RSM)//RSM
                        {
                            EscEmail1 = getDepotRSMUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo1 == others)//other
                        {
                            if (CaseConfigEntity.Attributes.Contains("ber_escalationemail1"))
                                EscEmail1 = CaseConfigEntity.Attributes["ber_escalationemail1"].ToString();
                        }
                    }
                    #endregion

                    #region If Escalation TAT 2 > 0
                    if (EscTAT2 > 0)
                    {
                        EscDate2 = getEscalationDate(_service, DateTime.Now, EscTAT2);
                        if (EscTo2 == DepoUser)//DepoUser
                        {
                            EscEmail2 = getDepoUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo2 == DepoManager)//DepoManager
                        {
                            Entity oDepot = _service.Retrieve("ber_depot", Depot.Id, new ColumnSet(new string[] { "ber_escalationemail" }));
                            if (oDepot.Attributes.Contains("ber_escalationemail"))
                                EscEmail2 = oDepot.Attributes["ber_escalationemail"].ToString();
                        }
                        else if (EscTo2 == RSM)//RSM
                        {
                            EscEmail2 = getDepotRSMUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo2 == others)//other
                        {
                            if (CaseConfigEntity.Attributes.Contains("ber_escalationemail2"))
                                EscEmail2 = CaseConfigEntity.Attributes["ber_escalationemail2"].ToString();
                        }
                    }
                    #endregion

                    #region If Escalation TAT 3 > 0
                    if (EscTAT3 > 0)
                    {
                        EscDate3 = getEscalationDate(_service, DateTime.Now, EscTAT3);
                        if (EscTo3 == DepoUser)//DepoUser
                        {
                            EscEmail3 = getDepoUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo3 == DepoManager)//DepoManager
                        {
                            Entity oDepot = _service.Retrieve("ber_depot", Depot.Id, new ColumnSet(new string[] { "ber_escalationemail" }));
                            if (oDepot.Attributes.Contains("ber_escalationemail"))
                                EscEmail3 = oDepot.Attributes["ber_escalationemail"].ToString();
                        }
                        else if (EscTo3 == RSM)//RSM
                        {
                            EscEmail3 = getDepotRSMUserEmailId(_service, Depot.Id);
                        }
                        else if (EscTo3 == others)//other
                        {
                            if (CaseConfigEntity.Attributes.Contains("ber_escalationemail3"))
                                EscEmail3 = CaseConfigEntity.Attributes["ber_escalationemail3"].ToString();
                        }
                    }
                    #endregion

                    #region Update Case
                    Entity ServiceRequest = new Entity();
                    ServiceRequest.LogicalName = "incident";
                    ServiceRequest.Id = CaseId;

                    ServiceRequest.Attributes["ber_escalationemail1"] = EscEmail1;
                    ServiceRequest.Attributes["ber_escalationemail2"] = EscEmail2;
                    ServiceRequest.Attributes["ber_escalationemail3"] = EscEmail3;
                    if (EscTAT1 > 0)
                    {
                        ServiceRequest.Attributes["ber_escalationdate1"] = EscDate1;
                        ServiceRequest.Attributes["pcl_duedate"] = EscDate1;
                    }
                    if (EscTAT2 > 0)
                        ServiceRequest.Attributes["ber_escalationdate2"] = EscDate2;
                    if (EscTAT3 > 0)
                        ServiceRequest.Attributes["ber_escalationdate3"] = EscDate3;

                    _service.Update(ServiceRequest);

                    #endregion

                    break;
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("SREscalationManagement", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        #region Function to get Case Configuration basis of SRT & SubSRT of Case
        public static EntityCollection RetriveCaseConfig(IOrganizationService _service, Guid SRId, Guid SubSRId)
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='pcl_caseconfiguration'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='pcl_srtypeid' operator='eq' uitype='pcl_srtype' value='" + SRId + "'/>");
                query.Append("<condition attribute='pcl_subsrtypeid' operator='eq' uitype='pcl_subsrtype' value='" + SubSRId + "'/>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());

            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "RetriveCaseConfig", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }

        public static EntityCollection RetriveCaseConfig(IOrganizationService _service, Guid SRId, Guid SubSRId, int nCustomerCategory, int nLocation)
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='pcl_caseconfiguration'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='pcl_srtypeid' operator='eq' uitype='pcl_srtype' value='" + SRId + "'/>");
                query.Append("<condition attribute='pcl_subsrtypeid' operator='eq' uitype='pcl_subsrtype' value='" + SubSRId + "'/>");                
                query.Append("<condition attribute='ber_customercategory' operator='eq' value='" + nCustomerCategory + "'/>");
                query.Append("<condition attribute='ber_location' operator='eq' value='" + nLocation + "'/>");
                query.Append("<condition attribute='statecode' operator='eq' value='0'/>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());

            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "RetriveCaseConfig", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to Calculate Escalaton date
        public static DateTime getEscalationDate(IOrganizationService _service, DateTime SRCreatedOn, Double TATDays)
        {
            int TAT = 0;
            DateTime OldEscalationDate = DateTime.Now;
            DateTime NewEscalationDate = DateTime.Now;
            try
            {
                OldEscalationDate = SRCreatedOn;
                NewEscalationDate = SRCreatedOn.AddDays(TATDays);

                do
                {
                    TAT = getBusinessClosureCount(_service, OldEscalationDate, NewEscalationDate);
                    OldEscalationDate = NewEscalationDate;
                    NewEscalationDate = NewEscalationDate.AddDays(Convert.ToDouble(TAT));
                }
                while (TAT > 0);

                //check the new escalation date is holoday/weekend
                int tentativedatecount;
                do
                {
                    tentativedatecount = Convert.ToInt32(CheckCurrentDate(_service, NewEscalationDate));
                    NewEscalationDate = NewEscalationDate.AddDays(Convert.ToDouble(tentativedatecount));
                }
                while (tentativedatecount > 0);

            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "getEscalationDate", ex.Message, ex.StackTrace.ToString());
            }
            return NewEscalationDate;
        }
        #endregion

        #region Function to get Depot User Email address
        public static string getDepoUserEmailId(IOrganizationService _service, Guid DepotId)
        {
            string EmailId = string.Empty;
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='systemuser'>");
                query.Append("<attribute name='systemuserid' />");
                query.Append("<attribute name='internalemailaddress' />");
                query.Append("<link-entity name='ber_depot' from='ber_depotuser' to='systemuserid' alias='ab'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_depotid' operator='eq' value='" + DepotId + "' />");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());
                foreach (Entity oUserEntity in Result.Entities)
                {
                    if (oUserEntity.Attributes.Contains("internalemailaddress"))
                        EmailId = oUserEntity.Attributes["internalemailaddress"].ToString();
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "getDepoUserEmailId", ex.Message, ex.StackTrace.ToString());
            }
            return EmailId;
        }
        #endregion

        #region Function to get Depot RSM User Email id
        public static string getDepotRSMUserEmailId(IOrganizationService _service, Guid DepotId)
        {
            string EmailId = string.Empty;
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='systemuser'>");
                query.Append("<attribute name='systemuserid' />");
                query.Append("<attribute name='internalemailaddress' />");
                query.Append("<order attribute='internalemailaddress' descending='false' />");
                query.Append("<link-entity name='ber_region' from='ber_rsm' to='systemuserid' alias='ab'>");
                query.Append("<link-entity name='ber_depot' from='ber_region' to='ber_regionid' alias='ac'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_depotid' operator='eq' value='" + DepotId + "'/>");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());
                foreach (Entity oUserEntity in Result.Entities)
                {
                    if (oUserEntity.Attributes.Contains("internalemailaddress"))
                        EmailId = oUserEntity.Attributes["internalemailaddress"].ToString();
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "getDepotRSMUserEmailId", ex.Message, ex.StackTrace.ToString());
            }
            return EmailId;

        }
        #endregion

        #region Function to get TAT from Business Closure Days
        public static int getBusinessClosureCount(IOrganizationService _service, DateTime OldDate, DateTime NewDate)
        {
            int count = 0;
            try
            {
                string _oldDt = OldDate.Year + "-" + OldDate.Month + "-" + OldDate.Day;
                string _newDt = NewDate.Year + "-" + NewDate.Month + "-" + NewDate.Day;
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='ber_businessclosure'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_closuredate' operator='ge' value='" + _oldDt + "'/>");//2012-07-10T19:53:30+05:30
                query.Append("<condition attribute='ber_closuredate' operator='lt' value='" + _newDt + "'/>");
                query.Append("<condition attribute='ber_closurereason' operator='eq' value='278290001'/>");
                query.Append("<condition attribute='statecode' operator='eq' value='0'/>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection Result = Retrieve(_service, query.ToString());
                count = Result.Entities.Count;

                if (WeekEndDays.Count > 0)
                {
                    for (DateTime temp = OldDate; temp <= NewDate; temp = temp.AddDays(1))
                    {
                        foreach (string day in WeekEndDays)
                        {
                            if (temp.DayOfWeek.ToString() == day)
                            {
                                count++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "getBusinessClosureCount", ex.Message, ex.StackTrace.ToString());
            }
            return count;
        }
        #endregion

        #region Function to send email to the depo user
        public static void SendEmail(IOrganizationService _service, Guid SenderId, Guid ReceiverId, Guid RegardingId)
        {
            try
            {
                //WhoAmIRequest userRequest = new WhoAmIRequest();
                //WhoAmIResponse userResponse = (WhoAmIResponse)_service.Execute(userRequest);
                //Guid strUserId = new Guid(userResponse.UserId.ToString());

                ////Create an Email
                //Entity From = new Entity("activityparty");
                //From["partyid"] = new EntityReference("systemuser", strUserId);

                ////EscalationEmail.from = new CrmSdk.activityparty[] { From };
                //EntityCollection fromPartyColl = new EntityCollection();
                //fromPartyColl.Entities.Add(From);

                //EntityCollection toPartyColl = new EntityCollection();
                //Entity to = new Entity("activityparty");
                //to["partyid"] = new EntityReference("systemuser", ReceiverId);
                //toPartyColl.Entities.Add(to);                

                //Entity email = new Entity("email");
                //email["to"] = toPartyColl;
                //email["from"] = fromPartyColl;
                //email["subject"] = "Case Escalated";
                //email["description"] = "Case Description";
                //email["directioncode"] = true;

                //Guid EscalationEmailId = _service.Create(email);

                //SendEmailFromTemplateRequest emailRequest = new SendEmailFromTemplateRequest();
                //emailRequest.Target = email;
                //emailRequest.RegardingId = CaseId;
                //emailRequest.RegardingType = "incident";
                //emailRequest.TemplateId = new Guid("");
                //SendEmailFromTemplateResponse emailResponse = (SendEmailFromTemplateResponse)_service.Execute(emailRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "SendEmail", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion

        #region Function to Restrive Data from Fetch XMl
        private static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to check Escalation Date is holiday/weekend
        public static int CheckCurrentDate(IOrganizationService service, DateTime Dt)
        {
            int count = 0;
            try
            {
                string _newDt = Dt.Year + "-" + Dt.Month + "-" + Dt.Day;
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='ber_businessclosure'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_closuredate' operator='on' value='" + _newDt + "'/>");//2012-07-10T19:53:30+05:30
                query.Append("<condition attribute='ber_closurereason' operator='eq' value='278290001'/>");
                query.Append("<condition attribute='statecode' operator='eq' value='0'/>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection Result = Retrieve(service, query.ToString());
                count = Result.Entities.Count;

                if (count == 0 && WeekEndDays.Count > 0)
                {
                    foreach (string day in WeekEndDays)
                    {
                        if (Dt.DayOfWeek.ToString() == day)
                        {
                            count++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationManagement", "CheckCurrentDate", ex.Message, ex.StackTrace.ToString());
            }
            return count;
        }

        #endregion

        public static DateTime ChangeTime(DateTime dateTime, int hours, int minutes, int seconds, int milliseconds)
        {
            return new DateTime(
                dateTime.Year,
                dateTime.Month,
                dateTime.Day,
                hours,
                minutes,
                seconds,
                milliseconds,
                dateTime.Kind);
        }

    }
}
