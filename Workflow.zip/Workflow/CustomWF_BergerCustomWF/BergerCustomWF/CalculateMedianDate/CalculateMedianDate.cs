using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Runtime.CompilerServices;

namespace BergerWorkflowUtilities.CalculateMedianDate
{
	public class CalculateMedianDate : CodeActivity
	{
		[Input("End Date")]
		[RequiredArgument]
		public InArgument<DateTime> EndDate
		{
			get;
			set;
		}

		[Output("Median Date")]
		public OutArgument<DateTime> MedianDate
		{
			get;
			set;
		}

		[Input("Start Date")]
		[RequiredArgument]
		public InArgument<DateTime> StartDate
		{
			get;
			set;
		}

		public CalculateMedianDate()
		{
		}

		protected override void Execute(CodeActivityContext executionContext)
		{
			executionContext.GetExtension<ITracingService>();
			IWorkflowContext extension = executionContext.GetExtension<IWorkflowContext>();
			IOrganizationServiceFactory organizationServiceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
			organizationServiceFactory.CreateOrganizationService(new Guid?(extension.UserId));      // code modified after decompilation
			OutArgument<DateTime> medianDate = this.MedianDate;
			DateTime dateTime = this.StartDate.Get(executionContext);
			long ticks = dateTime.Ticks;
			dateTime = this.EndDate.Get(executionContext);
			medianDate.Set(executionContext, new DateTime((ticks + dateTime.Ticks) / (long)2));
		}
	}
}