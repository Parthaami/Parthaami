﻿// =====================================================================
//  This Custom Workflow Activity is used to update Payment advice status in ERP staging.
//  Once the Payment advice is Submited by Depot user by running ondemand workflow the same status will gets updated
//  in ERP staging also.(Status in ERP Posted/Failed)
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using System.Activities;

namespace BergerWorkflowUtilities.SubmitPaymentAdvice
{
    public class SubmitPA : CodeActivity
    {
        [Input("PA Status")]
        [RequiredArgument]
        public InArgument<string> PAStatus { get; set; }

        public static System.Configuration.Configuration config;
        public static Logger oLogger;
        public string _webService = string.Empty;
        public static WebReference.BergerOracleService OracleConnectService = new WebReference.BergerOracleService();

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);

            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;


            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region To Read Config File
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();

            string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, _loggerPath);
                    _webService = config.ConnectionStrings.ConnectionStrings["ERPConnectService"].ConnectionString.ToString();
                }
            }
            #endregion

            string PaymentAdviceStatus = executionContext.GetValue(this.PAStatus);
            OracleConnectService.Url = _webService;

            try
            {
                OracleConnectService.updatePaymentAdvise(entityId.ToString(), PaymentAdviceStatus);
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("SubmitPaymentAdvice", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
