﻿using Microsoft.Crm.Sdk;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Configuration;
using System.IO;
using System.Net;

namespace BergerWF_WhatsAppIntegration
{
    public class SendWhatsAppNotification : CodeActivity
    {
        public System.Configuration.Configuration config;
        public static Logger oLogger;

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("SendWhatAppNotification Workflow Started");
            //Create the context
            IWorkflowContext iworkflowcontext = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService _service = serviceFactory.CreateOrganizationService(iworkflowcontext.UserId);
            //Get the GUID and Name of entity.
            Guid entityId = iworkflowcontext.PrimaryEntityId;
            string entityName = iworkflowcontext.PrimaryEntityName;
            string _organizationName = iworkflowcontext.OrganizationName;

            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            #region
            RegistryKey rk = Registry.LocalMachine;
            RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
            RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
            RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
            Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

            string DB_path = obj_dbpath.ToString();
            #endregion

            //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
            string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
            string Loggerpath = string.Empty;

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     

                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
                else
                {
                    Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                    oLogger = new Logger(_organizationName, Loggerpath);
                }
            }
            else
            {
                Loggerpath = DB_path + "\\CRMWeb\\ISV\\";
                oLogger = new Logger(_organizationName, Loggerpath);
            }

            try
            {
                Entity Lead = (Entity)_service.Retrieve(iworkflowcontext.PrimaryEntityName, iworkflowcontext.PrimaryEntityId, new ColumnSet(true));
                string subject = Lead.Contains("subject") ? Lead.GetAttributeValue<string>("subject") : string.Empty;
                string phoneNumber = Lead.Contains("telephone1") ? Lead.GetAttributeValue<string>("telephone1") : string.Empty;
                string chatSource = Lead.Contains("ber_chatsource") ? Lead.GetAttributeValue<string>("ber_chatsource") : string.Empty;
                string chatStatus = Lead.Contains("ber_chatstatus") ? Lead.GetAttributeValue<string>("ber_chatstatus") : string.Empty;
                oLogger.Log("SendWhatsAppNotification", "Execute", "DataCapture As Follow", "LeadId-" + subject + ", phone number-" + phoneNumber + ", chatSource-" + chatSource + ", chatStatus-" + chatStatus);

                if (phoneNumber != string.Empty && subject != string.Empty)
                {
                    if (chatSource != string.Empty || chatStatus != string.Empty)
                    {
                        WhatsAppAPICall(phoneNumber, subject, tracingService);
                    }
                }
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("SendWhatsAppNotification", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        public void WhatsAppAPICall(string phoneNumber, string LeadId, ITracingService tracingService)
        {
            oLogger.Log("SendWhatsAppNotification", "WhatsAppAPICall", "API Call Initiated", "API Call Initiated");
            string data = "{\"phone\":\"+91" + phoneNumber + "\",\"media\":{\"type\":\"media_template\",\"template_name\":\"enguiry_id\",\"lang_code\":\"en\",\"body\":[{\"text\":\"" + LeadId + "\"}]}}";
            tracingService.Trace("API Call Created");
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            HttpWebRequest postRequest = (HttpWebRequest)WebRequest.Create("https://apis.rmlconnect.net/wba/v1/messages");
            string response = "";
            postRequest.ContentType = "application/json";
            postRequest.Method = "POST";
            postRequest.Timeout = 5000;
            postRequest.Headers.Add("Authorization", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiQmVyZ2VyVyIsInVzZXJuYW1lIjoiQmVyZ2VyVyIsImV4cCI6MTk1MzcyMTQ1OSwiZW1haWwiOiJkZWJheWFuYmFuZXJqZWVAYmVyZ2VyaW5kaWEuY29tIiwib3JpZ19pYXQiOjE2MzgzNjE0NTksImN1c3RvbWVyX2lkIjoiTjVhOVBCZzh3NThTIn0.YFUe5PS0U-tooXAO_09k_40ceyImcynQhqL04IMvuZo");
            //using (var stream = request.GetRequestStream())
            StreamWriter requeststream = new StreamWriter(postRequest.GetRequestStream());
            requeststream.Write(data);
            requeststream.Close();
            //Get Response
            tracingService.Trace("request json- " + data);
            oLogger.Log("SendWhatsAppNotification", "WhatsAppAPICall", "API Request Json Data", data);
            HttpWebResponse getResponse = (HttpWebResponse)postRequest.GetResponse();
            StreamReader sr = new StreamReader(getResponse.GetResponseStream());
            response = sr.ReadToEnd().Trim();
            sr.Close();
            oLogger.Log("SendWhatsAppNotification", "WhatsAppAPICall", "API response", response);
            tracingService.Trace("response-" + response);
        }
    }

}
